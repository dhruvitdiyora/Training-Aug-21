export interface Crisis {
  id: number;
  name: string;
}
